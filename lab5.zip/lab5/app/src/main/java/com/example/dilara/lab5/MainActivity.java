package com.example.dilara.lab5;

import android.content.Context;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void lab5(View view){
        String introOption = "";
        String mainIdeaOption = "";
        String mainIdeaOption2 = "";
        String mainIdeaOption3 = "";
        String conclusionOption = "";
        ImageView image = (ImageView)findViewById(R.id.imageView);

        Spinner options = (Spinner)findViewById(R.id.spinnerOptions);
        String writingFormat = String.valueOf(options.getSelectedItem());

        RadioGroup pageNumber = (RadioGroup) findViewById(R.id.radioGroup);
        int pageNum = pageNumber.getCheckedRadioButtonId();

        ToggleButton toggle = (ToggleButton) findViewById(R.id.toggleButton);
        boolean mood = toggle.isChecked();

        CheckBox adventureCheckBox = (CheckBox) findViewById(R.id.checkBoxAdventure);
        Boolean adventure = adventureCheckBox.isChecked();

        CheckBox personalCheckBox = (CheckBox) findViewById(R.id.checkBoxPersonal);
        Boolean personal = personalCheckBox.isChecked();

        CheckBox scaryCheckBox = (CheckBox) findViewById(R.id.checkBoxScary);
        Boolean scary = scaryCheckBox.isChecked();

        CheckBox cuteCheckBox = (CheckBox) findViewById(R.id.checkBoxCute);
        Boolean cute = cuteCheckBox.isChecked();

        CheckBox funnyCheckBox = (CheckBox) findViewById(R.id.checkBoxFunny);
        Boolean funny = funnyCheckBox.isChecked();

        CheckBox magicCheckBox = (CheckBox) findViewById(R.id.checkBoxMagic);
        Boolean magic = magicCheckBox.isChecked();

        if(adventure){
            image.setImageResource(R.drawable.adventure);
        }
        if(personal){
            image.setImageResource(R.drawable.personal);
        }
        if(scary){
            image.setImageResource(R.drawable.scary);
        }
        if(cute){
            image.setImageResource(R.drawable.cute);
        }
        if(funny){
            image.setImageResource(R.drawable.funny);
        }
        if(magic){
            image.setImageResource(R.drawable.magic);
        }

        switch(writingFormat){
            case "Essay":
                introOption = getString(R.string.essayIntro);
                mainIdeaOption = getString(R.string.essayMainIdea);
                mainIdeaOption2 = getString(R.string.essayMainIdea2);
                mainIdeaOption3 = getString(R.string.essayMainIdea3);
                conclusionOption = getString(R.string.essayConclusion);
                break;
            case "Fairy Tale":
                introOption = getString(R.string.fairyIntro);
                mainIdeaOption = getString(R.string.fairyMainIdea);
                mainIdeaOption2 = getString(R.string.fairyMainIdea2);
                mainIdeaOption3 = getString(R.string.fairyMainIdea3);
                conclusionOption = getString(R.string.fairyConclusion);
                break;
            case "Story":
                introOption = getString(R.string.storyIntro);
                mainIdeaOption = getString(R.string.storyMainIdea);
                mainIdeaOption2 = getString(R.string.storyMainIdea2);
                mainIdeaOption3 = getString(R.string.storyMainIdea3);
                conclusionOption = getString(R.string.storyConclusion);
                break;
            case "Speech":
                introOption = getString(R.string.speechIntro);
                mainIdeaOption = getString(R.string.speechMainIdea);
                mainIdeaOption2 = getString(R.string.speechMainIdea2);
                mainIdeaOption3 = getString(R.string.speechMainIdea3);
                conclusionOption = getString(R.string.speechConclusion);
                break;
            case "Review":
                introOption = getString(R.string.reviewIntro);
                mainIdeaOption = getString(R.string.reviewMainIdea);
                mainIdeaOption2 = getString(R.string.reviewMainIdea2);
                mainIdeaOption3 = getString(R.string.reviewMainIdea3);
                conclusionOption = getString(R.string.reviewConclusion);
                break;
            default:
                introOption = getString(R.string.defaultIntro);
                mainIdeaOption = getString(R.string.defaultMainIdea);
                mainIdeaOption2 = getString(R.string.defaultMainIdea2);
                mainIdeaOption3 = getString(R.string.defaultMainIdea3);
                conclusionOption = getString(R.string.defaultConclusion);
                break;
        }

//      Result
        TextView resultingText = (TextView)findViewById(R.id.writingPlan);
        if(pageNum == 2131230857){
            resultingText.setText(String.format("%s\n %s\n%s\n %s %s\n%s\n %s", getString(R.string
                    .intro), introOption, getString(R
                    .string.mainIdea), mainIdeaOption, mainIdeaOption2, getString(R
                    .string
                    .conclusion), conclusionOption));
        } else if(pageNum == 2131230780){
            resultingText.setText(String.format("%s\n %s\n%s\n %s %s\n%s\n %s", getString(R.string
                    .intro), introOption, getString(R
                    .string.mainIdea), mainIdeaOption, mainIdeaOption3, getString
                    (R.string.conclusion), conclusionOption));
        } else {
            resultingText.setText(String.format("%s\n %s\n%s\n %s\n%s\n %s", getString(R.string
                    .intro), introOption, getString(R
                    .string.mainIdea), mainIdeaOption, getString(R.string.conclusion), conclusionOption));
        }


//      Toggle Button
        if(mood){
            Context context = getApplicationContext();
            int duration = Toast.LENGTH_SHORT;
            CharSequence message = "You rock! Cheer up!";
            Toast toast = Toast.makeText(context, message, duration);
            toast.show();
        } else {
            Context context = getApplicationContext();
            int duration = Toast.LENGTH_SHORT;
            CharSequence message = "Yay! Awesome day!";
            Toast toast = Toast.makeText(context, message, duration);
            toast.show();
        }
    }
}
