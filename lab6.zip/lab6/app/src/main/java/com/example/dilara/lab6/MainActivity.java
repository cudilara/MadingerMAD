package com.example.dilara.lab6;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageButton;

public class MainActivity extends AppCompatActivity {

    private Character myCharacter = new Character();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final ImageButton buttonTolkien = (ImageButton) findViewById(R.id.buttonTolkien);
        final ImageButton buttonGandalf = (ImageButton) findViewById(R.id.buttonGandalf);
        final ImageButton buttonBilbo = (ImageButton) findViewById(R.id.buttonBilbo);
        View.OnClickListener onclick = new View.OnClickListener(){
            public void onClick(View view){
                switch(view.getId()){
                    case R.id.buttonTolkien:
                        sendToQuote("Tolkien", view);
                        break;
                    case R.id.buttonGandalf:
                        sendToQuote("Gandalf", view);
                        break;
                    case R.id.buttonBilbo:
                        sendToQuote("Bilbo", view);
                        break;
                }
            }
        };
        buttonTolkien.setOnClickListener(onclick);
        buttonGandalf.setOnClickListener(onclick);
        buttonBilbo.setOnClickListener(onclick);
    }

    public void sendToQuote(String speaker, View view){
        myCharacter.setCharacterURL(speaker);
        String resultingQuote = myCharacter.getQuote();
        String resultingURL = myCharacter.getCharacterURL();

        Intent intent = new Intent(this, QuoteActivity.class);
        intent.putExtra("quote", resultingQuote);
        intent.putExtra("url", resultingURL);

        startActivity(intent);
    }
}
