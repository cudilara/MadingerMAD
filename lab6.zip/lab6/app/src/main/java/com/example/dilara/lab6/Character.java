package com.example.dilara.lab6;

/**
 * Created by dilara on 11/20/2017.
 */

public class Character {
    private String quote;
    private String characterURL;

    private void setQuote(String speaker){
        switch(speaker){
            case "Tolkien":
                quote = "If more of us valued food and cheer and song above hoarded gold, it " +
                        "would be a merrier world.";
                characterURL = "http://lotr.wikia.com/wiki/J.R.R._Tolkien";
                break;
            case "Gandalf":
                quote = "...so do all who live to see such times. But that is not for them to " +
                        "decide. All we have to decide is what to do with the time that is given " +
                        "us.";
                characterURL = "http://lotr.wikia.com/wiki/Gandalf";
                break;
            case "Bilbo":
                quote = "\"Go back?” he thought. “No good at all! Go sideways? Impossible! Go " +
                        "forward? Only thing to do! On we go!\"";
                characterURL = "http://lotr.wikia.com/wiki/Bilbo_Baggins";
                break;
            default:
                quote = "If more of us valued food and cheer and song above hoarded gold, it " +
                        "would be a merrier world.";
                characterURL = "https://en.wikipedia.org/wiki/J._R._R._Tolkien";
        }
    }
    public void setTheQuote(String speaker){
        setQuote(speaker);
    }
    public void setCharacterURL(String speaker){
        setQuote(speaker);
    }
    public String getQuote(){
        return quote;
    }
    public String getCharacterURL(){
        return characterURL;
    }
}
