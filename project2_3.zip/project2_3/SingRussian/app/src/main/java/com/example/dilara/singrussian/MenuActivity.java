package com.example.dilara.singrussian;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

public class MenuActivity extends AppCompatActivity {
    private Genre myGenre = new Genre();
    private String bottomImageWeb = "http://www.xn-----6kccbwybdaa5d6a1a8df1e.xn--p1ai/obyichai-i-obryadyi-tatar";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);
        final ImageView ladyImage = findViewById(R.id.ladyWithAccordion);
        final ImageView bottomImage = findViewById(R.id.nation_friendship_image);
        final Button button_kidszone_main = findViewById(R.id.button_kidszone);
        final Button button_war_main = findViewById(R.id.button_war);
        final Button button_communist_main = findViewById(R.id.button_communist);
        View.OnClickListener onclick = new View.OnClickListener(){
            public void onClick(View view){
                switch(view.getId()){
                    case R.id.button_kidszone:
                        setUpList("kidszone", view);
                        break;
                    case R.id.button_war:
                        setUpList("war", view);
                        break;
                    case R.id.button_communist:
                        setUpList("communist", view);
                        break;
                }
            }
        };
        ImageView.OnClickListener imageOnClick = new ImageView.OnClickListener(){
            public void onClick(View view){
                Context context = getApplicationContext();
                CharSequence noCareText[] = {"Плевать", "Мне по барабану", "Плевать мне с высокой" +
                        " башни", "Да пошло оно все", "Пофиг", "Мне все равно", "Ну и ладно", "Ну" +
                        " и пусть", "Мне абсолютно все равно"};
                Random random = new Random();
                int index = random.nextInt(9);
                Toast toast = Toast.makeText(context, noCareText[index], Toast.LENGTH_LONG);
                ViewGroup group = (ViewGroup) toast.getView();
                TextView messageTextView = (TextView) group.getChildAt(0);
                messageTextView.setTextSize(28);
                toast.show();
            }
        };
        ImageView.OnClickListener bottomImageOnClick = new ImageView.OnClickListener(){
            public void onClick(View view){
                Intent bottom_intent = new Intent(Intent.ACTION_VIEW);
                bottom_intent.setData(Uri.parse(bottomImageWeb));
                startActivity(bottom_intent);
            }
        };
        button_kidszone_main.setOnClickListener(onclick);
        button_war_main.setOnClickListener(onclick);
        button_communist_main.setOnClickListener(onclick);
        ladyImage.setOnClickListener(imageOnClick);
        bottomImage.setOnClickListener(bottomImageOnClick);
    }

    public void setUpList(String genre, View view){
        myGenre.setList(genre);
        String resultingGenre = myGenre.getList();

        Intent intent = new Intent(this, ListActivity.class);
        intent.putExtra("genre", resultingGenre);
        startActivity(intent);
    }
}
