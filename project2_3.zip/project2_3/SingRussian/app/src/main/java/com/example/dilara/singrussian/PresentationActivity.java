package com.example.dilara.singrussian;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.youtube.player.YouTubeBaseActivity;
import com.google.android.youtube.player.YouTubeInitializationResult;
import com.google.android.youtube.player.YouTubePlayer;
import com.google.android.youtube.player.YouTubePlayer.Provider;
import com.google.android.youtube.player.YouTubePlayerView;


// public class PresentationActivity extends AppCompatActivity, YouTubeBaseActivity implements
//        YouTubePlayer.OnInitializedListener {
public class PresentationActivity extends YouTubeBaseActivity implements
        YouTubePlayer.OnInitializedListener {
    private String songName;
    private static final int RECOVERY_REQUEST = 1;
    private YouTubePlayerView youTubeView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_presentation);

        youTubeView = (YouTubePlayerView) findViewById(R.id.youtube_view);
        youTubeView.initialize(Video.YOUTUBE_API_KEY, this);

        Intent intent = getIntent();
        songName = intent.getStringExtra("selectedItem");

        TextView songTextRussian = (TextView)findViewById(R.id.textRussianArea);
        TextView songTextEnglish = (TextView)findViewById(R.id.textEnglishArea);

        switch (songName){
            case "Песенка Мамонтенка / The Song of a Little Mamoth":
                songTextRussian.setText(R.string.text_ru_TheSongofaLittleMamoth);
                songTextEnglish.setText(R.string.text_en_TheSongofaLittleMamoth);
                break;
            case "Чему Учат в Школе / What School is Teaching":
                songTextRussian.setText(R.string.text_ru_WhatSchoolisTeaching);
                songTextEnglish.setText(R.string.text_en_WhatSchoolisTeaching);
                break;
            case "Колыбельная Звездочета / A Lullaby of an Old Astronomer":
                songTextRussian.setText(R.string.text_ru_ALullabyofanOldAstronomer);
                songTextEnglish.setText(R.string.text_en_ALullabyofanOldAstronomer);
                break;
            case "Кто Такие Фиксики / What Really are Fixies?":
                songTextRussian.setText(R.string.text_ru_WhatReallyareFixies);
                songTextEnglish.setText(R.string.text_en_WhatReallyareFixies);
                break;
            case "Колыбельная Медведицы / Mama Bear's Lullaby":
                songTextRussian.setText(R.string.text_ru_MamaBearsLullaby);
                songTextEnglish.setText(R.string.text_en_MamaBearsLullaby);
                break;
            case "Ничего на Свете Лучше Нету / There is Nothing Better in the World":
                songTextRussian.setText(R.string.text_ru_ThereisNothingBetterintheWorld);
                songTextEnglish.setText(R.string.text_en_ThereisNothingBetterintheWorld);
                break;
            case "Антошка / Antoshka":
                songTextRussian.setText(R.string.text_ru_Antoshka);
                songTextEnglish.setText(R.string.text_en_Antoshka);
                break;
            case "Облака / Clouds":
                songTextRussian.setText(R.string.text_ru_Clouds);
                songTextEnglish.setText(R.string.text_en_Clouds);
                break;
            case "Мы едем, едем, едем / We are Going to Far Lands":
                songTextRussian.setText(R.string.text_ru_WeareGoingtoFarLands);
                songTextEnglish.setText(R.string.text_en_WeareGoingtoFarLands);
                break;
            case "Песня Красной Шапочки / If You Follow the Path":
                songTextRussian.setText(R.string.text_ru_IfYouFollowthePath);
                songTextEnglish.setText(R.string.text_en_IfYouFollowthePath);
                break;
            case "Бьют Часы на Старой Башне / The Bells Are Ringing":
                songTextRussian.setText(R.string.text_ru_TheBellsAreRinging);
                songTextEnglish.setText(R.string.text_en_TheBellsAreRinging);
                break;
            case "Крылатые Качели / The Winged Swing":
                songTextRussian.setText(R.string.text_ru_TheWingedSwing);
                songTextEnglish.setText(R.string.text_en_TheWingedSwing);
                break;
            case "В Синем Море, в Белой Пене / Deep Blue Sea, Light White Foam":
                songTextRussian.setText(R.string.text_ru_DeepBlueSea);
                songTextEnglish.setText(R.string.text_en_DeepBlueSea);
                break;
            case "Кабы не Было Зимы / If There Were No Winter":
                songTextRussian.setText(R.string.text_ru_IfThereWereNoWinter);
                songTextEnglish.setText(R.string.text_en_IfThereWereNoWinter);
                break;
            case "Прекрасное Далеко / The Glorious Future":
                songTextRussian.setText(R.string.text_ru_TheGloriousFuture);
                songTextEnglish.setText(R.string.text_en_TheGloriousFuture);
                break;
            case "Голубой Вагон / Blue Coach":
                songTextRussian.setText(R.string.text_ru_BlueCoach);
                songTextEnglish.setText(R.string.text_en_BlueCoach);
                break;

            case "Темная Ночь / The Dark Night":
                songTextRussian.setText(R.string.text_ru_TheDarkNight);
                songTextEnglish.setText(R.string.text_en_TheDarkNight);
                break;
            case "День победы / Victory Day":
                songTextRussian.setText(R.string.text_ru_VictoryDay);
                songTextEnglish.setText(R.string.text_en_VictoryDay);
                break;
            case "На поле Танки Грохотали / In the field the tanks rumbled":
                songTextRussian.setText(R.string.text_ru_Thetanksrumbled);
                songTextEnglish.setText(R.string.text_en_Thetanksrumbled);
                break;
            case "Нежность / Tenderness":
                songTextRussian.setText(R.string.text_ru_Tenderness);
                songTextEnglish.setText(R.string.text_en_Tenderness);
                break;
            case "Бери шинель, пошли домой / Grab Your Trenchcoat, We\'re Going Home":
                songTextRussian.setText(R.string.text_ru_GrabYourTrenchcoat);
                songTextEnglish.setText(R.string.text_en_GrabYourTrenchcoat);
                break;
            case "Погоня / Chase":
                songTextRussian.setText(R.string.text_ru_Chase);
                songTextEnglish.setText(R.string.text_en_Chase);
                break;
            case "Лесной Олень / Fairy Deer":
                songTextRussian.setText(R.string.text_ru_FairyDeer);
                songTextEnglish.setText(R.string.text_en_FairyDeer);
                break;
            case "Александра/ Aleksandra":
                songTextRussian.setText(R.string.text_ru_Aleksandra);
                songTextEnglish.setText(R.string.text_en_Aleksandra);
                break;
            case "Белеет Мой Парус / The Sail":
                songTextRussian.setText(R.string.text_ru_TheSail);
                songTextEnglish.setText(R.string.text_en_TheSail);
                break;
            case "Если у Вас Нету Тети / If you have no Aunt":
                songTextRussian.setText(R.string.text_ru_IfyouhavenoAunt);
                songTextEnglish.setText(R.string.text_en_IfyouhavenoAunt);
                break;
        }
    }

    @Override
    public void onInitializationSuccess(Provider provider, YouTubePlayer player, boolean wasRestored) {
        if (!wasRestored) {
            switch (songName){
                case "Песенка Мамонтенка / The Song of a Little Mamoth":
                    player.cueVideo("LQsBJbMt17I");
                    break;
                case "Чему Учат в Школе / What School is Teaching":
                    player.cueVideo("kt0EyZcPjtg");
                    break;
                case "Колыбельная Звездочета / A Lullaby of an Old Astronomer":
                    player.cueVideo("v5zcV665OAQ");
                    break;
                case "Кто Такие Фиксики / What Really are Fixies?":
                    player.cueVideo("9MH5RgPdmRE");
                    break;
                case "Колыбельная Медведицы / Mama Bear's Lullaby":
                    player.cueVideo("nuOA--rq7vE");
                    break;
                case "Ничего на Свете Лучше Нету / There is Nothing Better in the World":
                    player.cueVideo("x2VGBNjxDgk");
                    break;
                case "Антошка / Antoshka":
                    player.cueVideo("uTSnIhMwN8c");
                    break;
                case "Облака / Clouds":
                    player.cueVideo("gkViUW4NUwY");
                    break;
                case "Мы едем, едем, едем / We are Going to Far Lands":
                    player.cueVideo("c3h_6ap_z_U");
                    break;
                case "Песня Красной Шапочки / If You Follow the Path":
                    player.cueVideo("LSDuvjMjEaQ");
                    break;
                case "Бьют Часы на Старой Башне / The Bells Are Ringing":
                    player.cueVideo("__LxHAo18DU");
                    break;
                case "Крылатые Качели / The Winged Swing":
                    player.cueVideo("niQQf38mhxc");
                    break;
                case "В Синем Море, в Белой Пене / Deep Blue Sea, Light White Foam":
                    player.cueVideo("WlgzamrHD18");
                    break;
                case "Кабы не Было Зимы / If There Were No Winter":
                    player.cueVideo("3o5MpxBCW08");
                    break;
                case "Прекрасное Далеко / The Glorious Future":
                    player.cueVideo("m7A4uy6Nw0k");
                    break;
                case "Голубой Вагон / Blue Coach":
                    player.cueVideo("XVDkdvEplrQ");
                    break;
                case "Темная Ночь / The Dark Night":
                    player.cueVideo("1vRYwaJC5FY");
                    break;
                case "День победы / Victory Day":
                    player.cueVideo("b-0ut0uXZW8");
                    break;
                case "На поле Танки Грохотали / In the field the tanks rumbled":
                    player.cueVideo("SjyZpe2ztEw");
                    break;
                case "Нежность / Tenderness":
                    player.cueVideo("8v3l4dHifYo");
                    break;
                case "Бери шинель, пошли домой / Grab Your Trenchcoat, We\'re Going Home":
                    player.cueVideo("zD4eIYbzC58");
                    break;
                case "Погоня / Chase":
                    player.cueVideo("fHP9TEKSiYE");
                    break;
                case "Лесной Олень / Enchanted Deer":
                    player.cueVideo("CHPfgP7OkGI");
                    break;
                case "Александра/ Aleksandra":
                    player.cueVideo("NS5KJ7QSh2A");
                    break;
                case "Белеет Мой Парус / The Sail":
                    player.cueVideo("voGYbmOMCws");
                    break;
                case "Если у Вас Нету Тети / If you have no Aunt":
                    player.cueVideo("uAOL2uOLfkU");
                    break;
            }

        }
    }

    @Override
    public void onInitializationFailure(Provider provider, YouTubeInitializationResult errorReason) {
        if (errorReason.isUserRecoverableError()) {
            errorReason.getErrorDialog(this, RECOVERY_REQUEST).show();
        } else {
            String error = String.format(getString(R.string.player_error), errorReason.toString());
            Toast.makeText(this, error, Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == RECOVERY_REQUEST) {
            // Retry initialization if user performed a recovery action
            getYouTubePlayerProvider().initialize(Video.YOUTUBE_API_KEY, this);
        }
    }

    protected Provider getYouTubePlayerProvider() {
        return youTubeView;
    }
}
