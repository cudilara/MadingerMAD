package com.example.dilara.singrussian;


public class Video {
    private Video(){

    }
    public static final String YOUTUBE_API_KEY = "AIzaSyC3XryaVPafCR8nkYZXP0shJLrXTvEt4ao";
}
