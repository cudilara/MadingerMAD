package com.example.dilara.singrussian;

public class Genre {
    private String songList;

    private void setSongList(String genre){
        switch(genre){
            case "cartoon":
                songList = "cartoon";
                break;
            case "war":
                songList = "war";
                break;
            case "communist":
                songList = "communist";
                break;
            default:
                songList = "communist";
        }
    }
    public void setList(String genre){
        setSongList(genre);
    }
    public String getList(){
        return songList;
    }
}
