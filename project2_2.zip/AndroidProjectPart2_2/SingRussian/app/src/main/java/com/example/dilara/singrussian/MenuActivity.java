package com.example.dilara.singrussian;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

public class MenuActivity extends AppCompatActivity {
    private Genre myGenre = new Genre();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);
        final Button button_cartoon_main = findViewById(R.id.button_cartoon);
        final Button button_war_main = findViewById(R.id.button_war);
        final Button button_communist_main = findViewById(R.id.button_communist);
        View.OnClickListener onclick = new View.OnClickListener(){
            public void onClick(View view){
                switch(view.getId()){
                    case R.id.button_cartoon:
                        setUpList("cartoon", view);
                        break;
                    case R.id.button_war:
                        setUpList("war", view);
                        break;
                    case R.id.button_communist:
                        setUpList("communist", view);
                        break;
                }
            }
        };
        button_cartoon_main.setOnClickListener(onclick);
        button_war_main.setOnClickListener(onclick);
        button_communist_main.setOnClickListener(onclick);
    }

    public void setUpList(String genre, View view){
        myGenre.setList(genre);
        String resultingGenre = myGenre.getList();

        Intent intent = new Intent(this, ListActivity.class);
        intent.putExtra("genre", resultingGenre);
        startActivity(intent);
    }
}
