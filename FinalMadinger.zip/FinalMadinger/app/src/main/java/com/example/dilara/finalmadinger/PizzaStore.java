package com.example.dilara.finalmadinger;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

public class PizzaStore extends AppCompatActivity {
    private String text;
    private String url;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pizza_store);

        Intent intent = getIntent();
        text = intent.getStringExtra("whatPizza");
        url = intent.getStringExtra("url");

        TextView finalText = (TextView)findViewById(R.id.textView);
        finalText.setText(text);

        final ImageButton urlButton = (ImageButton) findViewById(R.id.imageButton);
        View.OnClickListener onclick  = new View.OnClickListener(){
            public void onClick(View view){
                loadWebSite(view);
            }
        };
        urlButton.setOnClickListener(onclick);
    }
    public void loadWebSite(View view){
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(url));
        startActivity(intent);
    }
}
