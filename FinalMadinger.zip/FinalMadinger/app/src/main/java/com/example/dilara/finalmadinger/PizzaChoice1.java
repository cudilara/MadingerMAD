package com.example.dilara.finalmadinger;

/**
 * Created by dilara on 12/16/2017.
 */

public class PizzaChoice1 {
        private String finalURL;
        private String finalText;

        private void setPizza(String pizzaType){
            switch(pizzaType){
                case "gluten-free":
                    finalText = "You should check out Pizzeria Locale.";
                    finalURL = "http://localeboulder.com/";
                    break;
                case "wheat dough":
                    finalText = "You should check out Old Chicago";
                    finalURL = "http://www.oldchicago.com/";
                    break;
            }
        }
        public void setText(String pizzaType){
            setPizza(pizzaType);
        }
        public String getFinalText(){
            return finalText;
        }

        public void setURL(String pizzaType){
            setPizza(pizzaType);
        }
        public String getURL(){
            return finalURL;
        }
}
