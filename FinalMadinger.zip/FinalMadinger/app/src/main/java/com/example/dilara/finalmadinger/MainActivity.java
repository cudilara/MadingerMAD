package com.example.dilara.finalmadinger;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.ToggleButton;

public class MainActivity extends AppCompatActivity {
    private PizzaChoice1 myPizzaStore = new PizzaChoice1();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void displayPizza(View view) {
        String size = "";
        String toppings = "";
        String sauce = "";
        String glutenType = "";

        RadioButton mRadioButtonThin = (RadioButton) findViewById(R.id.radioButtonThin);
        RadioButton mRadioButtonThick = (RadioButton) findViewById(R.id.radioButtonThick);
        Button mStoreButton = (Button)findViewById(R.id.buttonFindPizza);

        Switch mSwitch = (Switch) findViewById(R.id.switch1);
        final boolean gluten = mSwitch.isChecked();

        EditText mEdit = (EditText)findViewById(R.id.editText);
        String pizzaName = mEdit.getText().toString();

        Spinner mSpinner = (Spinner) findViewById(R.id.spinner);
        String pizzaType = String.valueOf(mSpinner.getSelectedItem());

        TextView mTextView = (TextView) findViewById(R.id.textViewPizza);

        ToggleButton mToggleButton = (ToggleButton) findViewById(R.id.toggleButton);
        final boolean sauceColor = mToggleButton.isChecked();

        CheckBox mCheckBoxPepperoni = (CheckBox) findViewById(R.id.checkBoxPepperoni);
        boolean pepperoni = mCheckBoxPepperoni.isChecked();

        CheckBox mCheckBoxOnion = (CheckBox) findViewById(R.id.checkBoxOnion);
        boolean onion = mCheckBoxOnion.isChecked();

        CheckBox mCheckBoxMushrooms = (CheckBox) findViewById(R.id.checkBoxMushrooms);
        boolean mushrooms = mCheckBoxMushrooms.isChecked();

        CheckBox mCheckBoxSausage = (CheckBox) findViewById(R.id.checkBoxSausage);
        boolean sausage = mCheckBoxSausage.isChecked();

        final Button mButtonPizza = (Button) findViewById(R.id.buttonPizza);
        ImageView mImageViewPizza = (ImageView) findViewById(R.id.imageViewPizza);

        Button mButtonFindPizza = (Button) findViewById(R.id.buttonFindPizza);

        if(pepperoni && onion && mushrooms && sausage){
            mImageViewPizza.setImageResource(R.drawable.pizza_supreme);
            toppings = getString(R.string.topAll);
        }
        if(onion || mushrooms){
            mImageViewPizza.setImageResource(R.drawable.pizza_veggie);
            toppings = getString(R.string.topOnionMush);
        }
        if(pepperoni || sausage){
            mImageViewPizza.setImageResource(R.drawable.pizza_meat);
            toppings = getString(R.string.topPepSaus);
        }
        if(!pepperoni && !onion && !mushrooms && !sausage){
            mImageViewPizza.setImageResource(R.drawable.pizza_cheese);
            toppings = getString(R.string.topChz);
        }
        switch(pizzaType){
            case "small":
                size = getString(R.string.small);
                break;
            case "medium":
                size = getString(R.string.medium);
                break;
            case "large":
                size = getString(R.string.large);
                break;
        }
        if(sauceColor){
            sauce = getString(R.string.red);
        } else {
            sauce = getString(R.string.white);
        }

        if(gluten){
            glutenType = getString(R.string.glutenfree);
        } else {
            glutenType = getString(R.string.wheatdough);
        }

        View.OnClickListener onclick = new View.OnClickListener(){
            public void onClick(View view){
                if(gluten){
                    sendToStore(getString(R.string.glutenfree), view);
                } else {
                    sendToStore(getString(R.string.wheatdough), view);
                }
            }
        };
        mStoreButton.setOnClickListener(onclick);
        mTextView.setText("The " + pizzaName + " is a " + size + " " + glutenType +" pizza with " +
                sauce + " " +
                "sauce and "
                + toppings + ".");


    }

    public void sendToStore(String pizzaType, View view){
        myPizzaStore.setText(pizzaType);
        String resultingText = myPizzaStore.getFinalText();
        String resultingURL = myPizzaStore.getURL();

        Intent intent = new Intent(this, PizzaStore.class);
        intent.putExtra("whatPizza", resultingText);
        intent.putExtra("url", resultingURL);

        startActivity(intent);
    }
}
